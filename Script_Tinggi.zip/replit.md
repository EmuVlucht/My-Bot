# Quantum Voyager WhatsApp Bot

## Overview

Quantum Voyager is an automated WhatsApp bot built with Node.js that provides three core features: scheduled profile picture rotation based on time and holidays, AI-powered chat responses through multiple providers, and dual authentication methods for flexible deployment.

The bot operates on Asia/Jayapura timezone (WIT) and manages profile pictures automatically while responding to user commands with AI-generated content from various providers including OpenAI, Anthropic, Google, and Microsoft.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Technologies
- **Runtime**: Node.js
- **WhatsApp Integration**: whatsapp-web.js with LocalAuth session management
- **Scheduling**: node-cron for automated tasks
- **Time Management**: moment-timezone for Asia/Jayapura (WIT) timezone operations

### Authentication System
**Dual Login Support**:
- **Primary Method**: QR Code scanning (default) - Uses qrcode-terminal to display scannable QR codes in console
- **Alternative Method**: Pairing code - Configured via environment variables `LOGIN_METHOD=pairing` and `PHONE_NUMBER=628xxx`

**Session Persistence**: Uses LocalAuth strategy with persistent storage in `.wwebjs_auth/session-whatsapp-bot-pp/` directory to maintain login state across restarts

### Profile Picture Management

**Automatic Rotation Logic**:
- **Night Mode** (malam.png): 17:00-04:59 WIT
- **Day Mode** (siang.png): 05:00-11:59 & 13:00-16:59 WIT  
- **Special Mode** (khusus.jpg): 12:00-12:59 WIT & all holidays (highest priority)

**Scheduling**: Cron job runs every 5 minutes to check and update profile picture based on current time and holiday status

**Holiday Detection**:
- Weekends (Saturday/Sunday) automatically trigger special profile picture
- Indonesian national holidays stored in `libur.json` with dates and descriptions
- Covers years 2025-2026 with major holidays including religious and national celebrations

### AI Integration Architecture

**Multi-Provider Support** - Five AI providers accessible via command prefixes:
- `$bota` - OpenAI ChatGPT (via openai npm package)
- `$botb` - Anthropic Claude (via @anthropic-ai/sdk)
- `$botc` - Blackbox AI (via axios HTTP requests)
- `$botd` - Google Gemini (via @google/generative-ai)
- `$bote` - Microsoft Copilot (via axios HTTP requests)

**Message Processing Flow**:
1. Bot receives WhatsApp message
2. Checks for command prefix ($bota through $bote)
3. Extracts user query after command
4. Routes to appropriate AI provider
5. Returns AI-generated response to user

**API Authentication**: Requires environment variables for API keys:
- `OPENAI_API_KEY` - OpenAI authentication
- `ANTHROPIC_API_KEY` - Anthropic Claude authentication  
- `GEMINI_API_KEY` - Google Gemini authentication
- Blackbox and Copilot accessed via HTTP without dedicated SDK

### Data Storage

**Static Configuration**:
- Holiday calendar stored in JSON format (`libur.json`)
- Profile pictures stored as static image files (malam.png, siang.png, khusus.jpg)

**Session Data**:
- WhatsApp authentication session persisted in `.wwebjs_auth/` directory
- Chromium-based browser data and cache for WhatsApp Web

### Error Handling & Resilience

**Design Considerations**:
- Cron-based checks ensure profile picture synchronization even after downtime
- Session persistence prevents re-authentication on restarts
- Multiple AI providers offer fallback options if one service fails

## External Dependencies

### Third-Party Services

**WhatsApp Platform**:
- Uses WhatsApp Web protocol via whatsapp-web.js
- Requires active WhatsApp account for bot identity
- Session management through browser automation (Chromium)

**AI Service Providers**:
1. **OpenAI** - ChatGPT API for conversational AI
2. **Anthropic** - Claude API for advanced reasoning
3. **Blackbox AI** - Alternative AI service via HTTP API
4. **Google** - Gemini generative AI platform
5. **Microsoft** - Copilot AI assistant

### NPM Packages

**Core Dependencies**:
- `whatsapp-web.js@^1.34.1` - WhatsApp Web API client
- `qrcode-terminal@^0.12.0` - QR code generation for terminal
- `node-cron@^4.2.1` - Task scheduling
- `moment-timezone@^0.6.0` - Timezone handling
- `axios@^1.12.2` - HTTP client for API requests

**AI SDKs**:
- `openai@^6.1.0` - OpenAI official SDK
- `@anthropic-ai/sdk@^0.65.0` - Anthropic official SDK
- `@google/generative-ai@^0.24.1` - Google Gemini SDK

### Configuration Requirements

**Environment Variables**:
- `OPENAI_API_KEY` - Required for OpenAI ChatGPT
- `ANTHROPIC_API_KEY` - Required for Claude
- `GEMINI_API_KEY` - Required for Google Gemini
- `LOGIN_METHOD` - Optional: "pairing" for pairing code auth
- `PHONE_NUMBER` - Required if using pairing method (format: 628xxx)

**Static Assets**:
- Profile picture images must be present in root directory
- Holiday configuration in libur.json for Indonesian calendar
- Write permissions for .wwebjs_auth directory for session storage