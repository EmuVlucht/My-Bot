const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const cron = require('node-cron');
const moment = require('moment-timezone');
const fs = require('fs');
const axios = require('axios');
const OpenAI = require('openai');
const Anthropic = require('@anthropic-ai/sdk');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const TIMEZONE = 'Asia/Jayapura';

let client;
let currentPP = null;

const libur = JSON.parse(fs.readFileSync('./libur.json', 'utf-8'));

console.log('🚀 Memulai Bot WhatsApp...');
console.log('📍 Timezone: ' + TIMEZONE);

function isHariLibur() {
    const today = moment.tz(TIMEZONE).format('YYYY-MM-DD');
    const dayOfWeek = moment.tz(TIMEZONE).day();
    
    if (dayOfWeek === 0 || dayOfWeek === 6) {
        return true;
    }
    
    if (libur[today]) {
        return true;
    }
    
    return false;
}

function getPPYangHarusDipakai() {
    const now = moment.tz(TIMEZONE);
    const hour = now.hour();
    
    if (isHariLibur()) {
        return 'khusus.jpg';
    }
    
    if (hour === 12) {
        return 'khusus.jpg';
    }
    
    if (hour >= 17 || hour < 5) {
        return 'malam.png';
    }
    
    if ((hour >= 5 && hour < 12) || (hour >= 13 && hour < 17)) {
        return 'siang.png';
    }
    
    return 'siang.png';
}

async function gantiPP() {
    try {
        const ppYangHarusDipakai = getPPYangHarusDipakai();
        
        if (currentPP === ppYangHarusDipakai) {
            console.log(`✅ PP sudah sesuai: ${ppYangHarusDipakai}`);
            return;
        }
        
        console.log(`🔄 Mengganti PP dari ${currentPP || 'default'} ke ${ppYangHarusDipakai}...`);
        
        const media = MessageMedia.fromFilePath(`./${ppYangHarusDipakai}`);
        await client.setProfilePicture(media);
        
        currentPP = ppYangHarusDipakai;
        const now = moment.tz(TIMEZONE).format('YYYY-MM-DD HH:mm:ss');
        console.log(`✅ PP berhasil diganti ke ${ppYangHarusDipakai} pada ${now}`);
        
    } catch (error) {
        console.error('❌ Error saat mengganti PP:', error.message);
    }
}

async function chatWithOpenAI(message) {
    try {
        const openai = new OpenAI({
            apiKey: process.env.OPENAI_API_KEY
        });
        
        const response = await openai.chat.completions.create({
            model: 'gpt-3.5-turbo',
            messages: [{ role: 'user', content: message }],
            max_tokens: 500
        });
        
        return response.choices[0].message.content;
    } catch (error) {
        console.error('Error OpenAI:', error.message);
        return '❌ Maaf, terjadi error saat menghubungi ChatGPT. Pastikan API key sudah diset.';
    }
}

async function chatWithClaude(message) {
    try {
        const anthropic = new Anthropic({
            apiKey: process.env.ANTHROPIC_API_KEY
        });
        
        const response = await anthropic.messages.create({
            model: 'claude-3-5-sonnet-20241022',
            max_tokens: 1024,
            messages: [{ 
                role: 'user', 
                content: [{ type: 'text', text: message }]
            }]
        });
        
        return response.content[0].text;
    } catch (error) {
        console.error('Error Claude:', error.message);
        return '❌ Maaf, terjadi error saat menghubungi Claude. Pastikan API key sudah diset.';
    }
}

async function chatWithBlackbox(message) {
    try {
        const response = await axios.post('https://api.blackbox.ai/api/chat', {
            messages: [{ role: 'user', content: message }],
            previewToken: null,
            userId: null,
            codeModelMode: true,
            agentMode: {},
            trendingAgentMode: {},
            isMicMode: false,
            isChromeExt: false,
            githubToken: null
        }, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        return response.data;
    } catch (error) {
        console.error('Error Blackbox:', error.message);
        return '❌ Maaf, terjadi error saat menghubungi Blackbox AI.';
    }
}

async function chatWithGemini(message) {
    try {
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
        
        const result = await model.generateContent(message);
        const response = await result.response;
        return response.text();
    } catch (error) {
        console.error('Error Gemini:', error.message);
        return '❌ Maaf, terjadi error saat menghubungi Gemini. Pastikan API key sudah diset.';
    }
}

async function chatWithCopilot(message) {
    try {
        const response = await axios.post('https://api.bing.microsoft.com/v7.0/search', {
            q: message
        }, {
            headers: {
                'Ocp-Apim-Subscription-Key': process.env.COPILOT_API_KEY || ''
            }
        });
        
        return response.data.webPages?.value[0]?.snippet || 'Copilot API memerlukan konfigurasi khusus.';
    } catch (error) {
        console.error('Error Copilot:', error.message);
        return '❌ Maaf, Microsoft Copilot API memerlukan Azure subscription dan konfigurasi khusus.';
    }
}

async function handleMessage(msg) {
    try {
        const body = msg.body;
        
        if (body.startsWith('$bot')) {
            const command = body.substring(4, 5).toLowerCase();
            const query = body.substring(5).trim();
            
            if (!query) {
                await msg.reply('❓ Silakan sertakan pertanyaan setelah command.\n\nContoh: $bota apa itu AI?');
                return;
            }
            
            console.log(`📨 Menerima pesan dari ${msg.from}: ${body}`);
            
            let response;
            
            switch (command) {
                case 'a':
                    await msg.reply('🤖 Memproses dengan ChatGPT...');
                    response = await chatWithOpenAI(query);
                    break;
                case 'b':
                    await msg.reply('🤖 Memproses dengan Claude...');
                    response = await chatWithClaude(query);
                    break;
                case 'c':
                    await msg.reply('🤖 Memproses dengan Blackbox AI...');
                    response = await chatWithBlackbox(query);
                    break;
                case 'd':
                    await msg.reply('🤖 Memproses dengan Gemini...');
                    response = await chatWithGemini(query);
                    break;
                case 'e':
                    await msg.reply('🤖 Memproses dengan Copilot...');
                    response = await chatWithCopilot(query);
                    break;
                default:
                    await msg.reply('❌ Command tidak dikenali.\n\nGunakan:\n$bota - ChatGPT\n$botb - Claude\n$botc - Blackbox\n$botd - Gemini\n$bote - Copilot');
                    return;
            }
            
            await msg.reply(response);
            console.log(`✅ Balasan terkirim ke ${msg.from}`);
        }
    } catch (error) {
        console.error('❌ Error handling message:', error.message);
        await msg.reply('❌ Maaf, terjadi error saat memproses pesan Anda.');
    }
}

async function initBot() {
    console.log('\n📲 Mode Login: QR Code');
    console.log('💡 Untuk pairing code, set environment variable: LOGIN_METHOD=pairing dan PHONE_NUMBER=628xxxxx\n');
    
    const loginMethod = process.env.LOGIN_METHOD || 'qr';
    const phoneNumber = process.env.PHONE_NUMBER || '';
    
    client = new Client({
        authStrategy: new LocalAuth({
            clientId: 'whatsapp-bot-pp'
        }),
        puppeteer: {
            headless: true,
            executablePath: '/nix/store/qa9cnw4v5xkxyip6mb9kxqfq1z4x2dx1-chromium-138.0.7204.100/bin/chromium',
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu'
            ]
        }
    });
    
    client.on('qr', async (qr) => {
        if (loginMethod === 'qr') {
            console.log('\n📱 Scan QR Code ini dengan WhatsApp Anda:');
            qrcode.generate(qr, { small: true });
        } else if (loginMethod === 'pairing' && phoneNumber) {
            try {
                const pairingCode = await client.requestPairingCode(phoneNumber, true);
                console.log('\n🔑 Kode Pairing Anda: ' + pairingCode);
                console.log('💡 Masukkan kode ini di WhatsApp Anda:');
                console.log('   WhatsApp > Linked Devices > Link a Device > Link with phone number');
            } catch (err) {
                console.log('⚠️ Error mendapatkan pairing code:', err.message);
                console.log('💡 Coba gunakan mode QR code saja (default).');
            }
        }
    });
    
    client.on('ready', async () => {
        console.log('\n✅ Bot WhatsApp siap!');
        console.log('📱 Nomor: ' + client.info.wid.user);
        
        console.log('\n⏰ Scheduler PP dimulai...');
        
        cron.schedule('*/5 * * * *', async () => {
            await gantiPP();
        }, {
            timezone: TIMEZONE
        });
        
        await gantiPP();
    });
    
    client.on('message', handleMessage);
    
    client.on('authenticated', () => {
        console.log('✅ Autentikasi berhasil!');
    });
    
    client.on('auth_failure', (msg) => {
        console.error('❌ Autentikasi gagal:', msg);
    });
    
    client.on('disconnected', (reason) => {
        console.log('⚠️ Bot terputus:', reason);
        console.log('🔄 Mencoba reconnect...');
    });
    
    if (loginMethod === 'pairing' && phoneNumber) {
        console.log('\n📞 Mode Pairing Code aktif');
        console.log('📱 Nomor: ' + phoneNumber);
        console.log('💡 Kode pairing akan ditampilkan saat koneksi dimulai...');
    }
    
    await client.initialize();
}

initBot().catch(console.error);
